package DefiningClassesExercises.DefineClassPerson;

import java.lang.reflect.Field;

/**
 * Created by r3v3nan7 on 22.02.17.
 */
public class Main {

    public static void main(String[] args){
        Class person = Person.class;

        Field[] fields = person.getDeclaredFields();
        System.out.println(fields.length);


    }


}