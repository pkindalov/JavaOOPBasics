package DefiningClassesExercises.DefineClassPerson;

/**
 * Created by r3v3nan7 on 22.02.17.
 */
public class Person {

    private int age;
    private String name;

    public int getAge(){
        return  this.age;
    }

    public String getName(){
        return this.name;
    }


}
